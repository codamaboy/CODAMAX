export default function Home() {
  return (
    <div style={{padding:40}}>
      <h1>🦄 ULTRA UNICORN PLATFORM</h1>
      <p>Global-scale fintech architecture starter</p>
    </div>
  );
}
