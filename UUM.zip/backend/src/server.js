const express = require("express");
const app = express();

app.use(express.json());

app.get("/", (_, res) => res.send("ULTRA UNICORN API 🦄"));

app.listen(5000, () => console.log("API running 5000"));
