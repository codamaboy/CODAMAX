export default function Admin() {
  return (
    <div style={{padding:40}}>
      <h1>Ultra Admin Panel</h1>
    </div>
  );
}
